import { useState, useEffect } from "react";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Navbar from "./components/Navbar";
import CadastrarLivro from "./pages/CadastrarLivro";
import Emprestimos from "./pages/Emprestimos";
import Perfil from "./pages/Perfil";
import LivroDetalhe from "./pages/LivroDetalhe";

function App() {
  const [user, setUser] = useState(null);
  const [pagina, setPagina] = useState("home");
  const [livros, setLivros] = useState([]);
  const [emprestimos, setEmprestimos] = useState([]);
  const [livroSelecionado, setLivroSelecionado] = useState(null);

  // 🔥 CARREGA DADOS
  useEffect(() => {
    const userSalvo = localStorage.getItem("user");
    if (userSalvo) setUser(JSON.parse(userSalvo));

    const livrosSalvos = localStorage.getItem("livros");
    if (livrosSalvos) {
      setLivros(JSON.parse(livrosSalvos));
    }
  }, []);

  // 🔥 SALVA LIVROS SEMPRE QUE MUDAR
  useEffect(() => {
    localStorage.setItem("livros", JSON.stringify(livros));
  }, [livros]);

  const adicionarLivro = (livro) => {
    setLivros((prev) => [...prev, livro]);
    setPagina("home");
  };

  if (!user) return <Login setUser={setUser} />;

  return (
    <>
      <Navbar setUser={setUser} setPagina={setPagina} />

      {pagina === "home" && (
        <Home
          livros={livros}
          setEmprestimos={setEmprestimos}
          setLivroSelecionado={setLivroSelecionado}
          setPagina={setPagina}
        />
      )}

      {pagina === "cadastrar" && (
        <CadastrarLivro adicionarLivro={adicionarLivro} />
      )}

      {pagina === "emprestimos" && (
        <Emprestimos
          emprestimos={emprestimos}
          setEmprestimos={setEmprestimos}
        />
      )}

      {pagina === "perfil" && (
        <Perfil user={user} emprestimos={emprestimos} />
      )}

      {pagina === "detalhe" && (
        <LivroDetalhe
          livro={livroSelecionado}
          emprestimos={emprestimos}
        />
      )}
    </>
  );
}

export default App;