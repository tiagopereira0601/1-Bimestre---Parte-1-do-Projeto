export default function LivroDetalhe({ livro, emprestimos }) {
  if (!livro) return <p>Sem livro</p>;

  const avaliacoes = emprestimos.filter(e => e.id === livro.id && e.status === "devolvido");

  return (
    <div style={{ marginTop: "100px", textAlign: "center" }}>
      <h2>{livro.titulo}</h2>

      <img src={livro.imagem} width="150" />
      <p>{livro.autor}</p>
      <p>{livro.sinopse}</p>

      {livro.pdf && (
        <a href={livro.pdf} download>
          <button>Baixar PDF</button>
        </a>
      )}

      <h3>Avaliações</h3>

      {avaliacoes.map((a, i) => (
        <div key={i}>
          <p>Nota: {a.nota}</p>
          <p>{a.feedback}</p>
        </div>
      ))}
    </div>
  );
}