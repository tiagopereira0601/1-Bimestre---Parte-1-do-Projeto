export default function Home({ livros, setEmprestimos, setLivroSelecionado, setPagina }) {

  const emprestar = (livro) => {
    setEmprestimos((prev) => [...prev, { ...livro, status: "emprestado" }]);
    alert("Livro emprestado!");
  };

  const abrir = (livro) => {
    setLivroSelecionado(livro);
    setPagina("detalhe");
  };

  return (
    <div style={{ marginTop: "100px", textAlign: "center" }}>
      <h2>Livros</h2>

      {livros.map(l => (
        <div key={l.id}>
          <img src={l.imagem} width="100" />
          <h3>{l.titulo}</h3>

          <button onClick={() => abrir(l)}>Ver</button>
          <button onClick={() => emprestar(l)}>Emprestar</button>
        </div>
      ))}
    </div>
  );
}