import { useState } from "react";

export default function CadastrarLivro({ adicionarLivro }) {
  const [titulo, setTitulo] = useState("");
  const [autor, setAutor] = useState("");
  const [sinopse, setSinopse] = useState("");
  const [imagem, setImagem] = useState(null);
  const [pdf, setPdf] = useState(null);

  const cadastrar = () => {
    adicionarLivro({
      id: Date.now(),
      titulo,
      autor,
      sinopse,
      imagem: imagem ? URL.createObjectURL(imagem) : "https://via.placeholder.com/150",
      pdf: pdf ? URL.createObjectURL(pdf) : null
    });
  };

  return (
    <div style={{ marginTop: "100px", textAlign: "center" }}>
      <h2>Cadastrar</h2>

      <input placeholder="Título" onChange={e => setTitulo(e.target.value)} /><br />
      <input placeholder="Autor" onChange={e => setAutor(e.target.value)} /><br />
      <input placeholder="Sinopse" onChange={e => setSinopse(e.target.value)} /><br />

      <p>Imagem:</p>
      <input type="file" onChange={e => setImagem(e.target.files[0])} />

      <p>PDF:</p>
      <input type="file" onChange={e => setPdf(e.target.files[0])} />

      <br /><br />
      <button onClick={cadastrar}>Salvar</button>
    </div>
  );
}