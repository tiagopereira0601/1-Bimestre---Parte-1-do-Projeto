import { useState } from "react";

export default function Login({ setUser }) {
  const [usuario, setUsuario] = useState("");
  const [senha, setSenha] = useState("");

  const handleLogin = () => {
    if (usuario === "tiago" && senha === "1") {
      const user = { nome: "Tiago" };

      localStorage.setItem("user", JSON.stringify(user));
      setUser(user);
    } else {
      alert("Usuário ou senha incorretos!");
    }
  };

  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh"
    }}>
      <div style={{
        background: "#ffffffcc",
        padding: "30px",
        borderRadius: "12px",
        textAlign: "center"
      }}>
        <h2>Login</h2>

        <input
          placeholder="Usuário"
          value={usuario}
          onChange={(e) => setUsuario(e.target.value)}
        />

        <input
          type="password"
          placeholder="Senha"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
        />

        <br />

        <button onClick={handleLogin}>Entrar</button>

        <p style={{ marginTop: "10px", fontSize: "12px" }}>
          
        </p>
      </div>
    </div>
  );
}