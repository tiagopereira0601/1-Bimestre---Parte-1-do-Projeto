export default function Perfil({ user, emprestimos }) {
  return (
    <div style={{ marginTop: "100px", textAlign: "center" }}>
      <h2>Perfil</h2>
      <p>Nome: {user.nome}</p>
      <p>Empréstimos: {emprestimos.length}</p>
    </div>
  );
}