import { useState } from "react";

export default function Emprestimos({ emprestimos, setEmprestimos }) {
  const [nota, setNota] = useState({});
  const [feedback, setFeedback] = useState({});

  const devolver = (id) => {
    setEmprestimos(prev =>
      prev.map(l =>
        l.id === id
          ? { ...l, status: "devolvido", nota: nota[id], feedback: feedback[id] }
          : l
      )
    );
  };

  return (
    <div style={{ marginTop: "100px", textAlign: "center" }}>
      <h2>Empréstimos</h2>

      {emprestimos.map(l => (
        <div key={l.id}>
          <h3>{l.titulo}</h3>

          {l.status === "emprestado" ? (
            <>
              <input placeholder="Nota" onChange={e => setNota({ ...nota, [l.id]: e.target.value })} />
              <input placeholder="Feedback" onChange={e => setFeedback({ ...feedback, [l.id]: e.target.value })} />
              <button onClick={() => devolver(l.id)}>Devolver</button>
            </>
          ) : (
            <p>Devolvido - Nota: {l.nota}</p>
          )}
        </div>
      ))}
    </div>
  );
}