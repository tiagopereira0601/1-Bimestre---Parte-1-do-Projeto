const API = "http://localhost:3001";

export const login = async (email, senha) => {
  const res = await fetch(`${API}/usuarios?email=${email}&senha=${senha}`);
  const data = await res.json();
  return data[0];
};

export const getLivros = async () => {
  const res = await fetch(`${API}/livros`);
  return res.json();
};

export const emprestarLivro = async (livro, usuario) => {
  await fetch(`${API}/emprestimos`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      livroId: livro.id,
      usuarioId: usuario.id,
      status: "emprestado"
    })
  });

  await fetch(`${API}/livros/${livro.id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ disponivel: false })
  });
};

export const devolverLivro = async (id, nota, feedback) => {
  await fetch(`${API}/emprestimos/${id}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      status: "devolvido",
      nota,
      feedback
    })
  });
};