export default function Navbar({ setUser, setPagina }) {
  const logout = () => {
    localStorage.removeItem("user");
    setUser(null);
  };

  return (
    <div style={{
      position: "fixed",
      top: 0,
      width: "100%",
      background: "#4CAF50",
      color: "#fff",
      padding: "15px",
      display: "flex",
      justifyContent: "space-around"
    }}>
      <span onClick={() => setPagina("home")}>🏠 Home</span>
      <span onClick={() => setPagina("emprestimos")}>📚 Empréstimos</span>
      <span onClick={() => setPagina("perfil")}>👤 Perfil</span>
      <span onClick={() => setPagina("cadastrar")}>➕ Cadastrar</span>
      <button onClick={logout}>Sair</button>
    </div>
  );
}